# NICOLAS Elise & ANTON Christine

import torch
import matplotlib.pyplot as plt
import torchvision.transforms as transforms
from torch import nn
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor
from torchvision.transforms import v2
import numpy as np
from typing import *


def question1():
    '''
    Imprimer votre réponse 
    Afficher l'image sous la forme d'une image
    '''
    # Récupération du dataset
    train_dataset = datasets.MNIST(root='./MNIST', train=True, download=True)

    # Affichage du dataset
    img = train_dataset[0][0]
    plt.imshow(img)

    # Réponses aux questions
    print("Ce jeu de données contient des tuples composés de l'image et du label correspondant.")
    print(f"Les dimensions d'un échantillon sont {img.size}, ce qui correspond bien aux dimensions d'une image.")


def question2():
    '''
    Sortie:
    T : le tenseur de la forme [1,3,3,3] ne contenant que des 1.
    T1: la multiplication sur la dernière dimension du premier tenseur et la dernière dimension du deuxième
    T2: la multiplication de la deuxieme dimension du premier et la troisieme dimension du deuxieme tenseur
    Y: 3 copies de T stack les unes sur les autres
    Z: Y sous la forme d'un matrice  [9,9]
    '''
    # Question 1
    T = torch.ones((1,3,3,3))
    
    # Question 2
    T1 = torch.tensordot(T, T, dims=([3], [3]))
    #T1 = torch.einsum('abcd, efgd -> abcefg', T, T)

    # Question 3
    #T2 = torch.tensordot(T, T, dims=([1],[2]))
    T2 = torch.einsum('abcd, efbh -> acdefh', T, T)
    
    # Question 4
    Y = torch.stack((T, T, T))

    # Question 5
    Z = Y.reshape(9,9)
    
    return T,T1,T2,Y,Z


def question3(training_data):
    '''
    Entrée: training_data le jeu de donnée train de Mnist
    Imprimez vos réponses en précisant dans votre code (ou en faisant appel) les fonctions qui vous ont permis de trouver ces réponses
    '''
    # Question 1
    print("Nombre d'échantillons sur le jeu de données train :", len(training_data))

    # Question 2
    Y = set([training_data[i][1] for i in range(len(training_data))])
    print("Classes du dataset :", Y, "Nombre de classes :", len(Y))


def question4(training_data):
    ''' 
    Entrée: training_data le jeu de donnée train de Mnist
    Sortie: mnist_small_torch: le jeu de donné qui on comme label la deuxième classe qui est affichée par training_data.class_to_idx
    '''
    # Question 1
    classes = training_data.class_to_idx
    keys = list(classes.keys())
    s = classes[keys[1]]
    mnist_small_torch = [training_data[i][0] for i in range(len(training_data)) if training_data[i][1]==s]

    # Question 2
    print(f"Il y a {len(mnist_small_torch)} échantillons associés à la classe {s}.")
    print(f"Sachant que la taille du dataset est {len(training_data)}, cela nous parait cohérent, en effet cela représente un dixième du dataset et il y a {len(keys)} classes.")
    
    return mnist_small_torch


def decoupage_torch(training_data_list, test_data_list) -> Tuple[List[Tuple[torch.Tensor, int]], List[Tuple[torch.Tensor, int]]]: 
    '''
    Entrée:
    - training_data_list : la liste des couples (donnée,label) du trainset
    - test_data_list : la liste des couples (donnée,label) du testset

    Sortie:
    - restrict_train : List[Tuple[torch.Tensor, int]], liste des couples (donnée,label) du trainset pour les labels 7 et 9 
    - restrict_test : List[Tuple[torch.Tensor, int]], liste des couples (donnée,label) du testset pour les labels 7 et 9 
    '''
    def compute_restricted_dataset(dataset):
        res = []
        for i, (data,label) in enumerate(dataset) :
            if label == 7 :
                res.append((data, 0))
            if label == 9 : 
                res.append((data, 1))
        return res
    
    restrict_train = compute_restricted_dataset(training_data_list)
    restrict_test = compute_restricted_dataset(test_data_list)
    
    return restrict_train, restrict_test


def get_mean_std(restrict_dataset:List[torch.Tensor]) -> Tuple[torch.Tensor]:
    """
    Calcule la moyenne et l'écart-type de toutes les images du dataset

    Entrée : 
    - restrict_dataset : List[torch.Tensor], le training dataset restreint contenant une liste de tenseurs (images)
            
    Sorties :
    - mean : torch.Tensor de dimension 0 (scalaire)
    - std : torch.Tensor de dimension 0 (scalaire)
    """
    # Initialisation
    mean = 0.
    std = 0.
    n_samples = len(restrict_dataset)

    # Calcul de mean et std
    for image in restrict_dataset :
        image_mean = image.mean()
        image_std = image.std()
        
        mean += image_mean
        std += image_std
        
    # Normalisation
    mean /= n_samples
    std /= n_samples
    
    return mean, std


def Normalize_dataset(dataset:torch.Tensor) -> torch.utils.data.Dataset:
    ''' 
    Entrée:
    dataset : le jeu de donnée de tenseurs, c'est-à-dire un tenseur de taille 4 (la première dimension correspond au nombre d'éléments dans 
    le jeu de données ; le second correspond au nombre de couleurs/channel de l'image (ici 1 : les images sont en noir et blanc) ; les troisième 
    et quatrième correspondent à la longueur et largeur de l'image)

    Sortie:
    normalized_data : le jeu de données normalisé sous la forme d'un tenseur de taille 4
    '''
    # Calcul de la moyenne et de l'écart-type du dataset
    mean, std = get_mean_std(dataset)

    # Normalisation des données
    normalize_function = transforms.Normalize(mean, std)
    normalized_data = normalize_function(dataset)

    return normalized_data


def RandomCrop_dataset(dataset):
    ''' 
    Entrée:
    dataset : le jeu de donnée de tenseurs, c'est-à-dire un tenseur de taille 4 (la première dimension correspond au nombre d'éléments dans 
    le jeu de données ; le second correspond au nombre de couleurs/channel de l'image (ici 1 : les images sont en noir et blanc) ; les troisième 
    et quatrième correspondent à la longueur et largeur de l'image)

    Sortie:
    le jeu de données après application de RandomCrop_dataset sous la forme d'un tenseur de taille 4
    '''
    # Question 1
    print("RandomCrop est une transformation qui rogne aléatoirement l'image pour obtenir un rectangle de taille (h,w) si size est un\ntuple (h,w), ou un carré de taille (h,h) si size est un entier h).")

    # Question 2
    RandomCrop_dataset = transforms.RandomCrop(size=(24,10))
    cropped = []
    for image in dataset : 
        cropped.append(RandomCrop_dataset(image))

    return torch.stack(cropped)


def Choix_transformation(dataset):
    ''' 
    Entrée:
    dataset : le jeu de donnée de tenseurs, c'est-à-dire un tenseur de taille 4 (la première dimension correspond au nombre d'éléments dans 
    le jeu de données ; le second correspond au nombre de couleurs/channel de l'image (ici 1 : les images sont en noir et blanc) ; les troisième 
    et quatrième correspondent à la longueur et largeur de l'image)

    Sortie:
    le jeu de données après application de la transformation sous la forme d'un tenseur de taille 4
    '''
    # Question 1
    print("On choisit la fonction CenterCrop qui rogne l'image pour obtenir un carré centré de taille size.")

    # Question 2
    CenterCrop_dataset = transforms.CenterCrop(18)
    center_cropped = []
    for image in dataset : 
        center_cropped.append(CenterCrop_dataset(image))

    return torch.stack(center_cropped)


class Twolayers(torch.nn.Module):

    def __init__(self,ninput,noutput):
        super(Twolayers, self).__init__()

        self.linear1 = torch.nn.Linear(ninput, 200)
        self.activation = torch.nn.ReLU()
        self.linear2 = torch.nn.Linear(200, noutput)
        self.softmax = torch.nn.Softmax()

    def forward(self, input):
        '''
        Applique les deux couches de notre réseau de neurones aux données input

        Entrée : 
            - input : dataset

        Sortie : 
            - output : torch.Tensor de taille (1, ninput, noutput) 
        '''
        input = input.reshape((input.shape[0], 28*28))
        input = self.linear1(input)  
        input = self.activation(input) 
        input = self.linear2(input)  
        output = self.softmax(input)

        return output
    
ninput = 28*28
noutput = 9