import torch

def decoupage_torch(training_data_list, test_data_list) : 
    """
    Retourne le tenseur contitué des données correspondant aux labels 7 et 9
    ainsi que le vecteur (tenseur torch) de classe
    """
    
    def compute_restricted_dataset(dataset) :
        res = []
        vect_class=[]
        for i, (x,y) in enumerate(dataset) :
            if y == 7 :
                vect_class.append(0)
                res.append((x,y))
            if y == 9 : 
                vect_class.append(1)
                res.append((x,y))
            
        return res, torch.tensor(vect_class)
    
    restrict_train_data, restrict_train_labels = compute_restricted_dataset(training_data_list)
    restrict_test_data, restrict_test_labels = compute_restricted_dataset(test_data_list)
    
    return (restrict_train_data, restrict_train_labels), (restrict_test_data, restrict_test_labels)
        