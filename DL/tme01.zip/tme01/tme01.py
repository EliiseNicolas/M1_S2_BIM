# NICOLAS Elise & ANTON Christine

import torch
import matplotlib.pyplot as plt
import torchvision.transforms as transforms
from torch import nn
from torch.utils.data import DataLoader
from torchvision import datasets
from torchvision.transforms import ToTensor
import numpy as np

def question1():
    '''
    Imprimer votre réponse 
    Afficher l'image sous la forme d'une image
    '''
    # Retrieve dataset
    train_dataset = datasets.MNIST(root='./MNIST', train=True, download=True)

    # Display dataset
    img = train_dataset[0][0]
    plt.imshow(img)

    # Answers to questions
    print("Ce jeu de données contient des tuples composés de l'image et du label correspondant.")
    print(f"Les dimensions d'un échantillon sont {img.size}, ce qui correspond bien aux dimensions d'une image.")


# QUESTION 2


def question3():
    '''
    Imprimez vos réponses en précisant dans votre code (ou en faisant appel) les fonctions qui vous ont permis de trouver ces réponses
    '''
    # Question 1
    print("Nombre d'échantillons sur le jeu de données train :", len(training_data))

    # Question 2
    Y = set([training_data[i][1] for i in range(len(training_data))])
    print("Classes du dataset :", Y, "Nombre de classes :", len(Y))


def decoupage_torch(training_data_list, test_data_list) : 
    """
    Retourne le tenseur contitué des données correspondant aux labels 7 et 9
    ainsi que le vecteur (tenseur torch) de classe
    """
    
    def compute_restricted_dataset(dataset) :
        res = []
        vect_class=[]
        for i, (x,y) in enumerate(dataset) :
            if y == 7 :
                vect_class.append(0)
                res.append((x,y))
            if y == 9 : 
                vect_class.append(1)
                res.append((x,y))
            
        return res, torch.tensor(vect_class)
    
    restrict_train_data, restrict_train_labels = compute_restricted_dataset(training_data_list)
    restrict_test_data, restrict_test_labels = compute_restricted_dataset(test_data_list)
    
    return (restrict_train_data, restrict_train_labels), (restrict_test_data, restrict_test_labels)
        